package manager.exception;

public class ManagerSaveException extends RuntimeException {

    public ManagerSaveException(Throwable cause) {
        super(cause);
    }
}
