package manager.exception;

public class ManagerLoadFromFileException extends RuntimeException {

    public ManagerLoadFromFileException(Throwable cause) {
        super(cause);
    }
}
